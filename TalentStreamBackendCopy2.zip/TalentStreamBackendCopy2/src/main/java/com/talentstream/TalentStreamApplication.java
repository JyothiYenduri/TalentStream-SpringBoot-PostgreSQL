package com.talentstream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalentStreamApplication {

	public static void main(String[] args) {
		SpringApplication.run(TalentStreamApplication.class, args);
	}

}
