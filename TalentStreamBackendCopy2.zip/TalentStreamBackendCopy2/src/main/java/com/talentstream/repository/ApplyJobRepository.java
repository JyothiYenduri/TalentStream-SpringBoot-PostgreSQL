package com.talentstream.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.talentstream.entity.ApplyJob;

public interface ApplyJobRepository extends JpaRepository<ApplyJob, Long> {

}