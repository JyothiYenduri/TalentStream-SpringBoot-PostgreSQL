package com.talentstream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalentStreamApplicationTests {

	@Test
	void contextLoads() {
	}

}
